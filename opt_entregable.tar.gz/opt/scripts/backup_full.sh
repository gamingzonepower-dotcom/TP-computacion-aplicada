#!/bin/bash

if [ "$1" == "-help" ]; then
	echo "Ayuda: ./backup_full.sh [ORIGEN] [DESTINO]"
	exit 0
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y+%m%d)
NOMBRE=$(basename $ORIGEN)

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: Faltan argumentos. "
	exit 1
fi

if [ ! -d "$ORIGEN" ]; then
	echo "Error: Origen no existe. "
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: Destino no existe."
	exit 1
fi

ARCHIVO="$DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz"
tar -czf $ARCHIVO $ORIGEN

echo "Backup guardado en: $ARCHIVO"
