 poweroff
 poweroff
bash
hostnamectl set-hostname TPServer
reboot
ip a
mariadb < /root/db.sql
mkdir -p /root/.ssh
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh 
chmod 600 /root/.ssh/authorized_keys
curl localhost/index.php | head
apt install php-mysql -y && systemctl restart apache2
curl localhost/index.php | head
dhclient -r
dhclient -v
ip a
ip r
nano /etc/network/interfaces
systemctl restart networking
ping -c 3 google.com
poweroff
